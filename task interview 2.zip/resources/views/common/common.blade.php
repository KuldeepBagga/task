@include("common.header")
<div class="container">
    @yield("content")
</div>
@include("common.footer")