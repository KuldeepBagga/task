@include("common.header")
@include('common.nav')
<div class="container">
    @yield("content")
</div>
@include("common.footer")