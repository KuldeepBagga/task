
<?php $__env->startSection("title"); ?> Login <?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
<div class="card m-auto mt-3" style="width: 25rem;">
    <h5 class="card-header">Login</h5>
    <div class="card-body">
        <?php echo $__env->make("common.message", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form method="post" action="<?php echo e(route('login_submit')); ?>">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="email" class="form-label">Email address</label>
                <input type="text" name="email" class="form-control">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" name="password">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button type="submit" class="btn btn-primary">Login</button>
        </form>
        <hr>
        <span>New Here ? <a href="<?php echo e(route('register')); ?>" class="link-primary link-offset-2 link-underline-opacity-25 link-underline-opacity-100-hover">Create an account</a></span>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("common.common", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\website development\task interview 2\resources\views/login.blade.php ENDPATH**/ ?>