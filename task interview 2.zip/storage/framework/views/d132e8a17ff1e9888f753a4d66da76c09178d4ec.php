
<?php $__env->startSection("title"); ?> Dashboard <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card mt-3">
    <h5 class="card-header">Dashboard</h5>
    <div class="card-body">
        <?php echo $__env->make('common.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card">
            <div class="card-body p-3">

                <table class="table">
                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td colspan="2">
                            <div class="header">
                                <h5>Login Details</h5>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <th>Name</th>
                        <td><i class="bi bi-person-fill"></i> <?php echo e($user->name); ?></td>
                    </tr>
                    <tr>
                        <th>Email</th>
                        <td><i class="bi bi-envelope-at-fill"></i> <?php echo e($user->email); ?></td>
                    </tr>
                    <tr>
                        <th>Mobile</th>
                        <td><i class="bi bi-telephone-fill"></i> <?php echo e($user->mobile); ?></td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <a href="<?php echo e(route('update_login')); ?>" class="btn btn-success btn-sm">Edit Login Details</a>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <h5 class="header">Personal Details</h5>
                        </td>
                    </tr>
                    <tr>
                        <th>Address</th>
                        <td><i class="bi bi-geo-alt"></i> <?php echo e($user->details->address); ?></td>
                    </tr>
                    <tr>
                        <th>City</th>
                        <td><i class="bi bi-map"></i> <?php echo e($user->details->city); ?></td>
                    </tr>
                    <tr>
                        <th>State</th>
                        <td><i class="bi bi-geo"></i> <?php echo e($user->details->state); ?></td>
                    </tr>
                    <tr>
                        <th>Date of Birth</th>
                        <td><i class="bi bi-calendar-date"></i> <?php echo e($user->details->date_of_birth); ?></td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <a href="<?php echo e(route('update_user')); ?>" class="btn btn-success btn-sm">Edit Personal Details</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('common.with_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\website development\task interview 2\resources\views/dashboard.blade.php ENDPATH**/ ?>